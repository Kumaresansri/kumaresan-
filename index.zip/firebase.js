import { initializeApp } from "firebase/app";
import{createUserWithEmailAndPassword,signInWithEmailAndPassword,signOut,getAuth, onAuthStateChanged} from"firebase/auth"
import { useEffect,useState } from "react";


const firebaseConfig = {
  apiKey: "AIzaSyCbSPPDT0r74__HGGepQBpQpSaJIpXnFzQ",
  authDomain: "kumaresan25-24ca4.firebaseapp.com",
  projectId: "kumaresan25-24ca4",
  storageBucket: "kumaresan25-24ca4.appspot.com",
  messagingSenderId: "405833309783",
  appId: "1:405833309783:web:38a2bacb63c9535d4d8d12",
  measurementId: "G-ZZ0T1CEBHX"
};


const app = initializeApp(firebaseConfig);
const auth=getAuth()



 export function signup(email,password){
    return createUserWithEmailAndPassword(auth,email,password)
}
 export function login(email,password){
    return signInWithEmailAndPassword(auth,email,password)

}
 export function logout(){
    return signOut(auth)
}
  export function useAuth(){
    const [currentUser,setCurrentUser]=useState()
    useEffect(()=>{
        const x=onAuthStateChanged(auth,user=>setCurrentUser(user))
        return x

    },[])
    return currentUser
 }